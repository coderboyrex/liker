<?php
set_time_limit(0);
ob_start('ob_gzhandler');
require("../config.php");
$gettoken = mysql_query("SELECT * FROM `vip` ORDER BY RAND() LIMIT 0,4");

$kun = mysql_query("SELECT * FROM `BotExLike` ORDER BY RAND() LIMIT 0,1");
$ging = mysql_fetch_array($kun);

  while ($post = mysql_fetch_array($gettoken)){
  $token= $ging['access_token'];
                 $check = json_decode(file_get_contents('https://graph.facebook.com/me?access_token='.$token),true);
                       if(!$check[id]){  @mysql_query("DELETE FROM vip WHERE user_id ='".$ging['user_id']."' ");  continue; }

$result = mysql_query("SELECT * FROM `BotExLike` ORDER BY RAND() LIMIT 0,5");

   if($result){
       while($row = mysql_fetch_array($result)){

$cmt = $post['like'];
$token = $row['access_token'];
    $stat = json_decode(auto('https://graph.facebook.com/'.$post['user_id'].'/feed?fields=id&access_token='.$token.'&offset=0&limit=1'),true);

        for($i=1;$i<=count($stat[data]);$i++){
$sllike = $stat['data'][$i]['likes']['count']; 
    if ($sllike == $post['likemax'])
    {
        continue;
    }
             $com = json_decode(auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/comments?access_token='.$token.'&limit=50&fields=id'),true);
	          if(count($com['data']) > 0){
		      for($c=1;$c<=count($com[data]);$c++){
			auto('https://graph.facebook.com/'.$stat[data][$i-1][id].'/likes?access_token='.$token.'&method=post');
		      if($cmt=="1"){
			  echo auto('https://graph.facebook.com/'.$com[data][$c-1][id].'/likes?access_token='.$token.'&method=post');
                          }
		      }
	          }
             } 

        }
    }
}

 

mysql_free_result ($result);
unset ($result);

function auto($url) {
   $ch = curl_init();
   curl_setopt_array($ch, array(
      CURLOPT_CONNECTTIMEOUT => 5,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_URL            => $url,
      )
   );
   $result = curl_exec($ch);
   curl_close($ch);
   return $result;
}
?>