<?php
error_reporting(0);
$act = $_GET['act'];
if($act){
if(
$act == 'addvip' ||
$act == 'editlike' ||
$act == 'vipcurl' ||
$act == 'xoacurl' ||
$act == 'editlikecurl' ){
include 'chucnang/'.$act.'.php';
}
}else{
menu();
}
function menu(){
print'
<a href="?act=vipcurl" class="btn btn-success"> Thêm User Vip Curl</a> 
<a href="?act=editlikecurl" class="btn btn-info"> Sửa Like User Vip Curl</a> 
<a href="?act=xoacurl" class="btn btn-danger"> Xóa User Vip Curl</a> 
<a href="?act=addvip" class="btn btn-success"> Thêm User Vip</a> 
<a href="?act=editlike" class="btn btn-info"> Sửa User Like Max</a> 
<a href="add.php" class="btn btn-warning"> Import Token</a> 
<a href="check.php" class="btn btn-danger"> Check Token Live</a> 
';
}