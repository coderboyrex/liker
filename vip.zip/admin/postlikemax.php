<?php
include'../config.php';

$like = $_POST['likemax'];
if($like <=9) {
die('Số Like Không Được Nhỏ Hơn 10');
}
$f = fopen('maxlike.txt','w');
$ghi = fwrite($f,$like);
fclose($f);
if(!$ghi) {
echo "Tệp Tin maxlike.txt Chưa Được Tạo Ra";
}else {
mysql_query(
         "UPDATE 
            BotExLike
         SET
            `like` = '" . mysql_real_escape_string($like) . "'
      ");


 echo 'Đã Cập Nhật Số Like Lên '.$like;
}