<div class="input-group">
      <input type="text" id="id" class="form-control" placeholder="Nhập User ID Vip Curl">
      <input type="number" id="likemax" class="form-control" placeholder="Nhập Số Lượng Like">
    </div>
      <span class="input-group-btn">
<center>
        <button class="btn btn-danger" id="addvip" onclick="addlike()" title="Add User"> Cập Nhật</button>
      </span>





<!-- ÂDD VIP-->
 <script language="javascript">

function addlike() {
if(!$('#id').val()) {
alert("Hãy Nhập User ID Vip Curl");
}else if(!$('#likemax').val()) {
alert("Hãy Nhập Số Lượng Like Max All User");
}else {
addvipxuly();
}
}

   function addvipxuly(){
     $('#addvip').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "posteditlikecurl.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         id : $('#id').val(),likemax : $('#likemax').val()
                    },
                    success : function (result){
                        $('#addvip').html(result);
                    }
                });
}


</script>