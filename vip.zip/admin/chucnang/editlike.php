<div class="input-group">
      <input type="number" id="likemax" class="form-control" value="100">
    </div>
      <span class="input-group-btn">
<center>
        <button class="btn btn-danger" id="addvip" onclick="addlike()" title="Add User"> Cập Nhật</button>
      </span>





<!-- ÂDD VIP-->
 <script language="javascript">

function addlike() {
if(!$('#likemax').val()) {
alert("Hãy Nhập Số Lượng Like Max All User");
}else {
addvipxuly();
}
}

   function addvipxuly(){
     $('#addvip').html('<i class="fa fa-spinner fa-spin"></i> Đang Xử Lý');
                $.ajax({
                    url : "postlikemax.php",
                    type : "post",
                    dateType:"text",
                    data : {
                         likemax : $('#likemax').val()
                    },
                    success : function (result){
                        $('#addvip').html(result);
                    }
                });
}


</script>