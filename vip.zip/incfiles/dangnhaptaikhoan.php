<br>
<div class="panel-heading"><i class="fa fa-user"></i> <b> Cách 2: Đăng nhập bằng Cookie</b></div>
<div class="panel-body">
<div class="row">
  <div class="col-lg-6">
<center>
<div class="input-group">
      <input type="text" id="cookie" class="form-control" placeholder="Nhập Cookie Facebook của bạn vô đây">
      <span class="input-group-btn">
        <button class="btn btn-danger" id="submit2" onclick="login()" title="Đăng nhập"> Đăng Nhập</button>
      </span>
</div>
   </center>
<b color="green"> Hãy Dùng Cách Này Để Tránh Die Token</b><br>
<b> Lưu ý: </b><p>Nếu Bị Checkpoint Vị Trí, Đó Cũng Là Cuối Cùng Bạn Bị Checkpoint, Vui Lòng Chọn Đây Là Tôi :D
Chân Thành Cảm Ơn!</p></b>

  </div><!-- /.col-lg-6 -->
</div><!-- /.row -->
</div>