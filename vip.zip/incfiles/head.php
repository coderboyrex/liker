<!DOCTYPE html>
<html lang="vi">

<head>
	<title>LeTheTuanIT.BlogSpot.Com</title>
	<meta charset="utf-8">
<meta name="description" content="Hệ thống BotEx + Curl  Online">
<meta name="keywords" content="LeTheTuanIT.BlogSpot.Com, bot like, bot cam xuc, botcamxuc,bot reactions, reactions, reaction, camxuc, bot cam xuc, tang like, hack like facebook, buff like, auto cam xuc , bot cam xuc , bot like , bot ex like , hack like viet nam, trang web hack like facebook, auto like viet nam, buff like viet nam,cách tăng like stt facebook, hack like ảnh facebook, auto cam xuc , bot cam xuc , bot like , bot ex like hack like comment facebook, tăng like ảnh facebook, cách hack tăng like,share code auto like, xin code auto like, web auto like, auto sub , auto share , hack share , hack comments , hack bình luận, auto like sub , đọc trộm tin nhắn facebook , xem tin nhắn facebook không cần mật khẩu "/>
	<meta http-equiv="cache-control" content="public" />
	<meta http-equiv="pragma" content="public" />
	<meta property="og:description" name="description" content="Hệ thống BOTEx + Curl Online Facebook miễn phí, KHÔNG SPAM!">
<meta name="copyright" content="LeTheTuanIT.BlogSpot.Com"/>
<meta name="robots" content="index, follow"/>
<meta name='revisit-after' content='1 days'/>
<meta http-equiv="content-language" content="vi"/>
<meta property="og:url" content="http://LeTheTuanIT.BlogSpot.Com"/>
<meta property="og:type" content="website"/>
<meta property="og:title" content="Hệ thống BOT Ex + Curl Online Facebook miễn phí, KHÔNG SPAM!"/>
<meta property="og:locale" content="vi_VN"/>
<meta property="og:image" content="https://image.freepik.com/free-icon/thumb-up-to-like-on-facebook_318-37196.jpg">
<meta name="twitter:card" content="LeTheTuanIT.BlogSpot.Com">
<meta name="twitter:site" content="LeTheTuanIT.BlogSpot.Com">
<meta name="twitter:title" content="Hệ thống BOTEx + Curl Online Facebook miễn phí, KHÔNG SPAM!">
<meta name="twitter:description" content="Hệ thống BOT Ex + Curl Online Facebook miễn phí, KHÔNG SPAM!">
<meta name="author" content="Kunkey">
	<link rel="shortcut icon" href="https://www.facebook.com/favicon.ico" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
	<script src="/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<!-- Facebook -->
	<meta property="og:url" content="http://LeTheTuanIT.BlogSpot.Com/" />
	<meta property="og:image" content="https://image.freepik.com/free-icon/thumb-up-to-like-on-facebook_318-37196.jpg" />
	<meta property="og:description" name="description" content="Hệ thống BOT Ex + Curl Online Facebook miễn phí, KHÔNG SPAM!">
	<meta property="og:site_name" content="LeTheTuanIT.BlogSpot.Com"> </head>
<?php
include'hieuung.php';
?>
<body>
	<div class="container">
		<nav class="navbar navbar-default">
			<ul class="nav nav-pills">
				<li class="active" data-toggle="tooltip" data-placement="bottom" title="Trang chủ"><a aria-expanded="true" href="http://LeTheTuanIT.BlogSpot.Com"">Home</a>
				</li>
				<li class="" data-toggle="tooltip" data-placement="bottom" title="Tài khoản"><a href="#" data-toggle="modal" data-target="#profile" title="Profile">Profile</a>
				</li>
<li class="" data-toggle="tooltip" data-placement="bottom" title="Login Admin"><a href="#" data-toggle="modal" data-target="#admin" title="Login Admin">Admin</a>
				</li>
				<li class="dropdown"> <a aria-expanded="false" class="dropdown-toggle" data-toggle="dropdown" href="#">
      Menu <span class="caret"></span>
    </a>
					<ul class="dropdown-menu">
						<li><a href="#" data-toggle="modal" data-target="#gioithieu" title="Update Curl">Update Curl</a>
						</li>
						<li><a href="#" data-toggle="modal" data-target="#muavip" title="Bảng Giá Vip Like"> Giá Vip Like</a>
						</li>
						</li>
						<li><a href="#" data-toggle="modal" data-target="#huongdan" title="Hướng dẫn">Hướng dẫn</a>
						</li>
						<!--<li class="divider"></li>-->
					</ul>
				</li>
			</ul>
		</nav>
	</div>
	<div class="container">
		<div class="alert alert-danger"> <strong><i class="glyphicon glyphicon-send"></i></strong> Bot Like & Ex Like <b>LeTheTuanIT.BlogSpot.Com</b> - ReOpen Style Bởi <b>Kunkey</b></div>
	</div>
	<div id="myTabContent" class="tab-content">
		<div class="tab-pane fade active in" id="home">
			<div class="container">
				<div class="panel panel-default">