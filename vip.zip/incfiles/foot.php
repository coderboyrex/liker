<div class="container">
<div class="panel panel-default">
 <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> <b> Vip Curl Like Member</b>
                            </div>
                            <div class="panel-body">
<div class="row">
<?php
$listvip = mysql_query("SELECT * FROM `curl` ORDER BY RAND() LIMIT 0,5");
        while($vipc = mysql_fetch_assoc($listvip))
        {

?>
<div class="list-group-item">
<div class="row-fluid">
<div class="media">
<a class="pull-left" href="http://www.facebook.com/<?php echo $vipc['user_id']; ?>" target="_blank">
<img src="http://graph.facebook.com/<?php echo $vipc['user_id']; ?>/picture?width=75&amp;height=75" class="media-object"/></a>

<div class="media-body">

<span class="media-heading clearfix">
Tên: <a href="http://www.facebook.com/<?php echo $vipc['user_id']; ?>"
target="_blank"><?php echo $vipc['name'];?></a>
</span><br>
<span class="media-heading clearfix">ID:<b> <?php echo $vipc['user_id']; ?></b>
</span><br>
<span class="media-heading clearfix">Like Max:<b> <?php echo $vipc['likemax']; ?> Like</b><br>
<span class="media-heading clearfix">Tình Trạng:<b> <?php echo $vipc['trangthai']; ?></b>
</span><br>
</span>
</div>
</div>
</div></div>
 <?php }?> 
</div>
</div>
                            <div class="panel-footer">
<?php
$babygay = mysql_query ("SELECT name, COUNT(name) FROM curl");
$robersgay = mysql_fetch_array($babygay);
$recsgay =$robersgay['COUNT(name)']; 
?>
<center> Có Tổng <?php echo $recsgay; ?> Vip Curl Member!</center>
                            </div>
                        </div>

</div>
</div>












<div class="container">
<div class="panel panel-default">
 <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> <b> Vip Bot Member</b>
                            </div>
                            <div class="panel-body">
<div class="row">
<?php 
$tbvip = mysql_query("SELECT * FROM `vip` ORDER BY RAND() LIMIT 0,5");
        while($vip = mysql_fetch_assoc($tbvip))
        {

?>
<div class="list-group-item">
<div class="row-fluid">
<div class="media">
<a class="pull-left" href="http://www.facebook.com/<?php echo $vip['user_id']; ?>" target="_blank">
<img src="http://graph.facebook.com/<?php echo $vip['user_id']; ?>/picture?width=75&amp;height=75" class="media-object"/></a>

<div class="media-body">

<span class="media-heading clearfix">
Tên: <a href="http://www.facebook.com/<?php echo $vip['user_id']; ?>"
target="_blank"><?php echo $vip['name'];?></a>
</span><br>
<span class="media-heading clearfix">ID:<b> <?php echo $vip['user_id']; ?></b>
</span><br>
<span class="media-heading clearfix">Like Max:<b> <?php echo $vip['likemax']; ?> Like</b>
</span><br>
<span class="media-heading clearfix">Like Cmt:<b> <?php if($vip['like'] == '1') { echo 'Có';}else { echo 'Không';}; ?></b>
</span>
</div>
</div>
</div></div>
 <?php }?> 
</div>
</div>
                            <div class="panel-footer">
<?php
$baby = mysql_query ("SELECT name, COUNT(name) FROM vip");
$robers = mysql_fetch_array($baby);
$recs =$robers['COUNT(name)']; 
?>
<center> Có Tổng <?php echo $recs; ?> Vip Member!</center>
                            </div>
                        </div>

</div>
</div>











<div class="container">
<div class="panel panel-default">
 <div class="panel-heading"><i class="glyphicon glyphicon-user"></i> <b> Những Người dùng mới</b>
                            </div>
                            <div class="panel-body">
<div class="row">
<?php 
  $tb= mysql_query("SELECT * FROM BotExLike ORDER BY id DESC LIMIT 5");
        while($row = mysql_fetch_assoc($tb))
        {

?>
<div class="list-group-item">
<div class="row-fluid">
<div class="media">
<a class="pull-left" href="http://www.facebook.com/<?php echo $row['user_id']; ?>" target="_blank">
<img src="http://graph.facebook.com/<?php echo $row['user_id']; ?>/picture?type=square" class="img-circle"></a>

<div class="media-body">

<span class="media-heading clearfix">
<a href="http://www.facebook.com/<?php echo $row['user_id']; ?>"
target="_blank"> Tên: <?php echo $row['name'];?></a>
</span><br>
<span class="media-heading clearfix">ID:<b> <?php echo $row['user_id']; ?></b></img></span>
</div>
</div>
</div></div>
 <?php }?> 
</div>
</div>
                            <div class="panel-footer">
<?php
$babi = mysql_query ("SELECT name, COUNT(name) FROM BotExLike");
$rober = mysql_fetch_array($babi);
$rec=$rober['COUNT(name)']; 
?>
<center>Hiện tại đã có <span class="label label-default"><?php echo $rec; ?></span> thành viên sử dụng hệ thống của chúng tôi!</center>
                            </div>
                        </div>

</div>
</div>






<div class="footer-copyright">
        <div class="container">
        <center>© 2017 By LeTheTuan<center>
        </div>
      </div>
	  